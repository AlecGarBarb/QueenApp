package android.itesm.edu.queen;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SongTitlesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song_titles);


        Intent intent = new Intent();
        String value = songs[((int)(Math.random()* songs.length))];

        intent.putExtra("songTitle", value);
        setResult(Activity.RESULT_OK, intent);
        finish();
    }



    private String[] songs = {
            "Tenement Funster",
            "In the Lap of the Gods",
            "Hammer to Fall",
            "Don't Stop Me Now",
            "39",
            "Need Your Loving Tonight",
            "Seven Seas of Rhye",
            "Somebody to Love",
            "Keep Yourself Alive",
            "Brighton Rock",
            "Who Wants to Live Forever",
            "I Want It All",
            "Now I'm Here",
            "Radio Ga Ga",
            "Another One Bites the Dust",
            "Stone Cold Crazy",
            "You're My Best Friend",
            "Crazy Little Thing Called Love",
            "We Are the Champions",
            "Tie Your Mother Down",
            "Killer Queen",
            "Fat Bottomed Girls",
            "We Will Rock You",
            "Under Pressure",
            "Bohemian Rhapsody"

    };




}
